Hacker's Wallet v1.2

BY:
Greensteam,
Zero-waste Design,
Annalise Simonella
Paul Gault

---------------------------------
CONTENTS
---------------------------------

Documentation:

* How to make a Hacker's Wallet v.1.2 using reclaimed materials [.pdf, from the instructable http://www.instructables.com/id/How-to-make-a-Hackers-Wallet-v10-using-reclaime/]

* Quick assembly guide parts 1 and 2 [.jpg]
--------------------------------------------------

Physical:

* Hacker's Wallet v1.2 Layouts [.ai, .pdf and .svg]
----------------------------------------------------

Updates from v1.1
* length increased to accommodate �20 note (thanks to Paul Gault).

Updates from v1.0
* .pdf layout added
* artboards espanded in .svg and .ai layouts
   
Updates from v0.1
* Addition of instructions
* Improved order of sewing, esp. top edge
* addition of quick assembly guide (thanks to Annalise Simonella)
   
---------------------------------
LICENSE
---------------------------------
   
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) 
http://creativecommons.org/licenses/by-sa/3.0/